/*
$(document).ajaxSend(function(){
    $.ajax({
        type        : 'POST',
        url         : '/validate-session-ajax-request',
        dataType    : 'text',
        success     : function (jsonData) {
            console.log("JSON DATA "+jsonData);
            console.log("Checking session.....")
            let jsonObj = JSON.parse(jsonData);
            console.log("Status "+jsonObj.status);
            if (!jsonObj.status) window.location.href = '/session-expired';
            console.log("Session validated");
            return false;
        },
        error       : function (xhr, status, error) {
            console.log(error);
        }
    });
});
*/
