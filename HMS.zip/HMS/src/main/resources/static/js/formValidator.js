function displayErrorMsg($input, errMsg) {

    let $inputLabel = $("label[for='"+$input.attr('id')+"']");
    let $inputType  = $input.attr('type');

    if ($input.hasClass('is-valid'))
        $input.removeClass('is-valid');

    if ($inputLabel.hasClass('text-success'))
        $inputLabel.removeClass('text-success');

    if ($input.next('div').hasClass('invalid-feedback'))
        $input.next('div').html('').removeClass('invalid-feedback');

    $input.addClass('is-invalid');
    $inputLabel.addClass('text-danger');
    $input.next('div').html(errMsg).addClass('invalid-feedback');
}

function displaySuccessMsg($input) {

    let $inputLabel = $("label[for='"+$input.attr('id')+"']");
    let $inputType  = $input.attr('type');

    if ($input.hasClass('is-invalid'))
        $input.removeClass('is-invalid');

    if ($inputLabel.hasClass('text-danger'))
        $inputLabel.removeClass('text-danger');

    if ($input.next('div').hasClass('invalid-feedback'))
        $input.next('div').removeClass('invalid-feedback').html('');

    $input.addClass('is-valid');
    $inputLabel.addClass('text-success');
}
function resetForm(formId) {

}
function validateForm(formId) {

    let inputId = 0;
    let errArr  = [];

    let isValid;

    let inputs  = $('#'+formId).find(":input:not([type=button]):not([type=submit]):not([type=reset]):not([type=hidden])");

    $(inputs).each(function () {

        inputId++;
        let $input = $(this);
        let $inputType = $input.attr('type');

        if ($input.attr('required')){

            let inpErrMsg   = $input.attr('data-msg');
            let inputVal    = '';

            if ($inputType != 'checkbox')
                inputVal = $input.val();

            else if ($inputType == 'checkbox'){

                let name    = $input.attr('name');
                inputVal    = $("input[name='"+name+"']:checked").map(function () {return $(this).val().toString();}).get().join(',');
            }

            if (inputVal == ''){

                displayErrorMsg($input, inpErrMsg);
                errArr.push(0);

            }else {

                displaySuccessMsg($input);
                errArr.push(1);
            }
        }
    });

    if ($.inArray(0, errArr) > -1)
        isValid = false;
    else
        isValid = true;

    return isValid;
}