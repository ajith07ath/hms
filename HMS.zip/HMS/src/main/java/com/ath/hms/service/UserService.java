package com.ath.hms.service;

import com.ath.hms.modals.User;

import java.util.List;

public interface UserService {

    List<User> GetAllUsers();
    User GetUserById(Integer userId);
    void SaveUpdateUser(User user);
    void DeleteUser(User user);
}
