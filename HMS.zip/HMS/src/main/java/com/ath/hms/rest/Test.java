package com.ath.hms.rest;

public class Test {

    public static void main(String[] args) {

        String string   = "Hellow world";
        char[] charArr  = string.toCharArray();
        String tmp      = "";

        for (int i=charArr.length - 1; i>=0; i--)
            tmp += charArr[i];

        System.out.println(tmp);
    }
}
