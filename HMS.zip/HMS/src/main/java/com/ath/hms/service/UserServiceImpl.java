package com.ath.hms.service;

import com.ath.hms.modals.User;
import com.ath.hms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    @Autowired
    UserServiceImpl(UserRepository userRepository){
        this.userRepository = userRepository;
    }

    @Override
    public List<User> GetAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public User GetUserById(Integer userId) {
        User user   = new User();

        if (userId != 0)
            user = userRepository.findById(userId).get();

        return user;
    }

    @Override
    public void SaveUpdateUser(User user) {
        userRepository.save(user);
    }

    @Override
    public void DeleteUser(User user) {
        userRepository.delete(user);
    }
}
