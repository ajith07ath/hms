package com.ath.hms.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import javax.servlet.http.HttpSession;

@Controller
public class MenuController {

    @GetMapping("/config/role/role-config")
    public String RoleConfig(HttpSession session, Model model){
        return "config/userRole/user-role";
    }

    @GetMapping("/config/user/user-config")
    public String UserConfig(HttpSession session, Model model){
        return "config/user/user";
    }

}
