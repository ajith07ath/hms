package com.ath.hms.service;

import com.ath.hms.modals.Role;

import java.util.List;

public interface RoleService {

    List<Role> GetUserRoles();
    Role GetByRoleId(Integer roleId);
    void SaveRole(Role role);
    void DeleteRole(Role role);
}
