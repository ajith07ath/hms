package com.ath.hms.modals;

import javax.persistence.*;
import java.util.Objects;

@Entity
@Table(name = "db_ath_hms_module", uniqueConstraints = @UniqueConstraint(columnNames = "name"))
public class Module {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int moduleId;

    @Column(name = "name")
    private String name;

    @Column(name = "url")
    private String url;

    @Column(name = "path")
    private String path;

    @Column(name = "css_class")
    private String cssClass;

    @Column(name = "active")
    private boolean active;

    public Module() {
    }

    public Module(int moduleId, String name, String url, String path, String cssClass, boolean active) {
        this.moduleId = moduleId;
        this.name = name;
        this.url = url;
        this.path = path;
        this.cssClass = cssClass;
        this.active = active;
    }

    public int getModuleId() {
        return moduleId;
    }

    public void setModuleId(int moduleId) {
        this.moduleId = moduleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getCssClass() {
        return cssClass;
    }

    public void setCssClass(String cssClass) {
        this.cssClass = cssClass;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Module)) return false;
        Module module = (Module) o;
        return moduleId == module.moduleId &&
                active == module.active &&
                Objects.equals(name, module.name) &&
                Objects.equals(url, module.url) &&
                Objects.equals(path, module.path) &&
                Objects.equals(cssClass, module.cssClass);
    }

    @Override
    public int hashCode() {
        return Objects.hash(moduleId, name, url, path, cssClass, active);
    }

    @Override
    public String toString() {
        return "Module{" +
                "moduleId=" + moduleId +
                ", name='" + name + '\'' +
                ", url='" + url + '\'' +
                ", path='" + path + '\'' +
                ", cssClass='" + cssClass + '\'' +
                ", active=" + active +
                '}';
    }
}
