package com.ath.hms.controllers;

import com.ath.hms.modals.Role;
import com.ath.hms.modals.User;
import com.ath.hms.service.RoleService;
import com.ath.hms.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.ArrayList;
import java.util.List;


@Controller
public class UserController {

    private UserService userService;
    private RoleService roleService;

    @Autowired
    public UserController(UserService userService, RoleService roleService) {
        this.userService = userService;
        this.roleService = roleService;
    }

    @GetMapping("config/user/get-user-list")
    public ModelAndView GetAllUsers(Model model) {
        model.addAttribute("users", userService.GetAllUsers());
        return new ModelAndView("config/user/user-data :: user-list-fragment");
    }

    @GetMapping("config/user/get-user-modal")
    public ModelAndView GetUserModel(@ModelAttribute User user, Model model){
        boolean isEdit = false;
        if (user.getUserId() != 0) {isEdit = true;}
        model.addAttribute("user", userService.GetUserById(user.getUserId()));
        model.addAttribute("isEdit", isEdit);
        model.addAttribute("rolesList", roleService.GetUserRoles());
        return new ModelAndView("config/user/user-data :: user-modal-fragment");
    }

    @PostMapping("config/user/save-user")
    @ResponseBody
    public void SaveUser(@RequestBody String userForm) throws JsonProcessingException {
        User user           = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false).readValue(userForm, User.class);
        JSONArray   JArr    = new JSONArray(new JSONObject(userForm).getJSONArray("role"));
        List<Role> roles    = new ArrayList<>();

        for (Object object : JArr)
            roles.add(roleService.GetByRoleId(Integer.parseInt(object.toString())));

        user.setRoles(roles);
        user.setActive(true);

        if (user.getUserId() == 0){
            BCryptPasswordEncoder passwordEncoder   = new BCryptPasswordEncoder();
            String encodedPass                      = passwordEncoder.encode(user.getPassword());
            user.setPassword(encodedPass);
        }else
            user.setPassword(userService.GetUserById(user.getUserId()).getPassword());

        userService.SaveUpdateUser(user);
    }

    @PostMapping("config/user/block-unblock-user")
    @ResponseBody
    public void BlockUnblockUser(@RequestParam("userId") Integer userId, @RequestParam("status") Boolean status){
        User user = userService.GetUserById(userId);
        user.setActive(status);
        userService.SaveUpdateUser(user);
    }

    @PostMapping("config/user/delete-user")
    @ResponseBody
    public void DeleteUser(@RequestParam("userId") Integer userId){
        User user   = userService.GetUserById(userId);
        userService.DeleteUser(user);
    }
}
