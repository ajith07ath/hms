package com.ath.hms.modals;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "db_ath_hms_role", uniqueConstraints = @UniqueConstraint(columnNames = "name"))
public class Role implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int roleId;

    @Column(name = "name", unique = true)
    private String name;

    @OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
    @JoinTable(name = "db_ath_hms_role_modules", joinColumns = @JoinColumn(name = "role_id", referencedColumnName = "roleId"), inverseJoinColumns = @JoinColumn(name = "module_id", referencedColumnName = "moduleId"))
    private List<Module> modules;

    @Column(name = "active")
    private boolean active;

    public Role(){
    }

    public Role(int roleId, String name, List<Module> modules, boolean active) {
        this.roleId = roleId;
        this.name = name;
        this.modules = modules;
        this.active = active;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Module> getModules() {
        return modules;
    }

    public void setModules(List<Module> modules) {
        this.modules = modules;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Role)) return false;
        Role role = (Role) o;
        return roleId == role.roleId &&
                active == role.active &&
                Objects.equals(name, role.name) &&
                Objects.equals(modules, role.modules);
    }

    @Override
    public int hashCode() {
        return Objects.hash(roleId, name, modules, active);
    }

    @Override
    public String toString() {
        return "Role{" +
                "roleId=" + roleId +
                ", name='" + name + '\'' +
                ", modules=" + modules +
                ", active=" + active +
                "}";
    }
}
