package com.ath.hms.controllers;

import com.alibaba.fastjson.JSON;
import com.ath.hms.modals.Role;
import com.ath.hms.service.RoleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class RoleController {

    private final RoleService roleService;

    @Autowired
    public RoleController(RoleService roleService) {
        this.roleService = roleService;
    }

    @GetMapping("config/role/get-user-role-list")
    public ModelAndView GetUserRoleList(Model model){
        model.addAttribute("roles",roleService.GetUserRoles());
        return new ModelAndView("config/userRole/user-role-data :: role-list-fragment");
    }

    @GetMapping("config/role/get-user-role-modal")
    public ModelAndView GetUserRoleModal(@RequestParam("roleId") Integer roleId, Model model){
        Role role   = new Role();
        if (roleId != 0) role = roleService.GetByRoleId(roleId);
        model.addAttribute("role",role);
        return new ModelAndView("config/userRole/user-role-data :: user-role-modal-fragment");
    }

    @PostMapping("config/role/save-user-role")
    @ResponseBody
    public void SaveUserRole(@RequestBody String formData, Model model){
        Role role   = JSON.parseObject(formData.toString(), Role.class);
        role.setActive(true);
        roleService.SaveRole(role);
    }

    @PostMapping("config/role/block-unblock-user-role")
    @ResponseBody
    public void BlockUnBlobkUserRole(@RequestParam("roleId") Integer roleId, @RequestParam("status") Boolean status, Model model){
        Role role   = roleService.GetByRoleId(roleId);
        role.setActive(status);
        roleService.SaveRole(role);
    }

    @PostMapping("config/role/delete-user-role")
    @ResponseBody
    public void DeleteUser(@RequestParam("roleId") Integer roleId, Model model){
        Role role = roleService.GetByRoleId(roleId);
        if(role != null)
            roleService.DeleteRole(role);
    }
}
