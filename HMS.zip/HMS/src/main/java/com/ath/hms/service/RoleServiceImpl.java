package com.ath.hms.service;

import com.ath.hms.modals.Role;
import com.ath.hms.repository.RoleRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RoleServiceImpl implements RoleService {

    private final RoleRepository roleRepository;

    @Autowired
    public RoleServiceImpl(RoleRepository roleRepository) {
        this.roleRepository = roleRepository;
    }

    @Override
    public List<Role> GetUserRoles() {
        return roleRepository.findAll();
    }

    @Override
    public Role GetByRoleId(Integer roleId) {
        return roleRepository.findById(roleId).get();
    }

    @Override
    public void SaveRole(Role role) {
        roleRepository.save(role);
    }

    @Override
    public void DeleteRole(Role role) {
        roleRepository.delete(role);
    }
}
