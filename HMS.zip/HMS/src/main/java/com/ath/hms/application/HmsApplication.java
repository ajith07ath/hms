package com.ath.hms.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = {"com.ath.hms.service","com.ath.hms.application","com.ath.hms.controllers","com.ath.hms.repository","com.ath.hms.modals"})
@EnableJpaRepositories(basePackages = "com.ath.hms.repository")
@EntityScan(basePackages = "com.ath.hms.modals")
public class HmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(HmsApplication.class, args);
	}
}
