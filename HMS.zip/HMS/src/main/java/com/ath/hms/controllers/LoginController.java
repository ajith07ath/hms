package com.ath.hms.controllers;

import com.ath.hms.modals.User;
import com.ath.hms.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.support.RequestContextUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Map;

@Controller
public class LoginController {

    private final UserRepository userRepository;

    @Autowired
    public LoginController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @GetMapping("/login")
    public String Login(HttpSession session, HttpServletRequest request){
        if(request.getSession() != null)
            session.invalidate();
        Map<String, ?> inputFlashMap    = RequestContextUtils.getInputFlashMap(request);
        return "login/login";
    }

    @RequestMapping(value = "/process-login")
    public String processLogin(HttpSession session, HttpServletRequest request){
        Authentication authentication   = SecurityContextHolder.getContext().getAuthentication();
        String loginDateTime            = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(System.currentTimeMillis()));
        User user                       = userRepository.findUserByUserName(authentication.getName());
        String sysIp                    = request.getRemoteAddr();
        //Integer sessionId               = customService.SaveUserLogs(user.getUserId(), loginDateTime, 0, sysIp, true, null, null);

        session.setAttribute("userId", user.getUserId());
        session.setAttribute("userName", user.getUserName());
        //session.setAttribute("sessionId", sessionId);

        return "redirect:/home";
    }

    @RequestMapping(value = "/process-logout")
    public String processLogout(RedirectAttributes redirect, HttpSession session, HttpServletRequest request){
        Integer userId          = Integer.parseInt(session.getAttribute("userId").toString());
        int sessionId           = Integer.parseInt(session.getAttribute("sessionId").toString());
        String logoutDateTime   = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date(System.currentTimeMillis()));

        //customService.SaveUserLogs(userId, null, sessionId, null, false, logoutDateTime, "Normal logout");

        session.invalidate();
        redirect.addFlashAttribute("msg", "You are logged out successfully");
        redirect.addFlashAttribute("alertType","alert-success");

        return "redirect:/login";
    }

    @RequestMapping(value = "/login-error")
    public String loginError(RedirectAttributes redirect, HttpServletRequest request, HttpSession session){
        redirect.addFlashAttribute("msg", "Invalid Username / Password");
        redirect.addFlashAttribute("alertType", "alert-danger");
        return "redirect:/login";
    }

    @RequestMapping(value = "/session-expired")
    public String sessionExpired(RedirectAttributes redirect, HttpServletRequest request, HttpSession session){
        redirect.addFlashAttribute("msg", "Session Expired");
        redirect.addFlashAttribute("alertType", "alert-danger");
        return "redirect:/login";
    }
}
